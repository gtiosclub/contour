MultipeerConnectivity implementation saved before Network migration on 2026-10-04.

To restore: remove the current Packages/HarnessConnectivity/Sources/HarnessConnectivity directory (new Network helper files must not remain), then extract this archive at the repository root, replacing the package, tests, both config plists, and connectivity documentation. The Mac/iPhone controllers and UI use the same public API and need no changes. Commit this ZIP with the migration so teammates can restore it. Both apps must use the same transport version.
