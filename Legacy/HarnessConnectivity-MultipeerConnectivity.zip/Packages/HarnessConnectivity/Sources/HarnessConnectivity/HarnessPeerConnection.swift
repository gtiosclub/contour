import ContourCore
import Foundation
@preconcurrency import MultipeerConnectivity
import Observation

/// Transport shared by the two developer targets. All mutable state lives on MainActor.
@MainActor
@Observable
public final class HarnessPeerConnection {
    public enum Role: Sendable { case mac, phone }
    public enum Status: String, Sendable {
        case stopped, searching, connecting, connected
    }

    public private(set) var status: Status = .stopped
    public private(set) var peerName: String?
    public private(set) var lastError: String?
    public private(set) var receivedCount = 0
    public private(set) var sentCount = 0
    public private(set) var lastReceivedAt: Date?
    public private(set) var isReceiving = false

    /// Called once per new state; repeated heartbeat packets do not replay feedback.
    public var onGuidance: (@MainActor (GuidanceState) -> Void)?
    public var onInterrupted: (@MainActor () -> Void)?

    private static let serviceType = "contour-harness"
    private static let invitation = Data("contour-harness-v1".utf8)
    private let role: Role
    private let peerID: MCPeerID
    private var session: MCSession?
    private var browser: MCNearbyServiceBrowser?
    private var advertiser: MCNearbyServiceAdvertiser?
    private var delegate: PeerDelegate?
    private var ticker: Task<Void, Never>?
    private var availablePeers: [MCPeerID: String] = [:]
    private var pendingPeer: MCPeerID?
    private var invitationDeadline: Date?
    private var retryAt = Date.distantPast
    private var restartAt: Date?
    private var runID = UUID()
    private var inbox = HarnessPacketInbox()
    private var nextSequence: UInt64 = 0
    private var latestSnapshot: HarnessPacket?

    public init(role: Role, displayName: String? = nil) {
        self.role = role
        let name = displayName ?? "Contour \(role == .mac ? "Mac" : "Phone") \(ProcessInfo.processInfo.hostName)"
        peerID = MCPeerID(displayName: String(name.prefix(63)))
    }

    /// Idempotent. The phone advertises; the Mac discovers and invites one phone.
    public func start() {
        guard status == .stopped else { return }
        runID = UUID()
        nextSequence = 0
        if let old = latestSnapshot {
            latestSnapshot = makeHarnessPacket(old.state, kind: .snapshot)
        }
        let bridge = PeerDelegate { [weak self] event in
            Task { @MainActor in self?.handle(event) }
        }
        delegate = bridge
        let newSession = MCSession(peer: peerID, securityIdentity: nil, encryptionPreference: .required)
        newSession.delegate = bridge
        session = newSession
        status = .searching
        lastError = nil
        if role == .mac {
            let discovery = MCNearbyServiceBrowser(peer: peerID, serviceType: Self.serviceType)
            discovery.delegate = bridge
            browser = discovery
            discovery.startBrowsingForPeers()
        } else {
            let discovery = MCNearbyServiceAdvertiser(
                peer: peerID, discoveryInfo: ["role": "phone", "version": "1"],
                serviceType: Self.serviceType
            )
            discovery.delegate = bridge
            advertiser = discovery
            discovery.startAdvertisingPeer()
        }
        ticker = Task { [weak self] in
            while !Task.isCancelled {
                do { try await Task.sleep(for: .milliseconds(250)) }
                catch { return }
                guard let self else { return }
                self.tick()
            }
        }
    }

    public func stop() {
        let wasReceiving = isReceiving
        ticker?.cancel()
        ticker = nil
        browser?.stopBrowsingForPeers()
        advertiser?.stopAdvertisingPeer()
        session?.delegate = nil
        session?.disconnect()
        browser = nil
        advertiser = nil
        session = nil
        delegate = nil
        availablePeers.removeAll()
        pendingPeer = nil
        invitationDeadline = nil
        restartAt = nil
        inbox = HarnessPacketInbox()
        peerName = nil
        lastReceivedAt = nil
        isReceiving = false
        status = .stopped
        if wasReceiving { onInterrupted?() }
    }

    public func reconnect() {
        stop()
        start()
    }

    /// Continuous guidance uses immediate delivery; one-off outcomes use reliable delivery.
    /// Outcomes are never cached for replay after reconnecting.
    public func send(_ state: GuidanceState) {
        guard role == .mac, Self.isValid(state) else { return }
        if state.outcome != nil {
            let event = makeHarnessPacket(state, kind: .event)
            transmit(event, mode: .reliable)
            latestSnapshot = makeHarnessPacket(GuidanceState(timestamp: Date(), vector: nil), kind: .snapshot)
        } else {
            let snapshot = makeHarnessPacket(state, kind: .snapshot)
            latestSnapshot = snapshot
            transmit(snapshot, mode: .unreliable)
        }
    }

    private func makeHarnessPacket(_ state: GuidanceState, kind: HarnessPacket.Kind) -> HarnessPacket {
        nextSequence += 1
        return HarnessPacket(version: 1, runID: runID, sequence: nextSequence, kind: kind, state: state)
    }

    private func transmit(_ packet: HarnessPacket, mode: MCSessionSendDataMode) {
        guard let session, !session.connectedPeers.isEmpty else { return }
        do {
            let data = try JSONEncoder().encode(packet)
            try session.send(data, toPeers: session.connectedPeers, with: mode)
            sentCount += 1
        } catch { lastError = error.localizedDescription }
    }

    private func tick() {
        let now = Date()
        if let restartAt, now >= restartAt {
            reconnect()
            return
        }
        if let invitationDeadline, now >= invitationDeadline {
            reconnect()
            return
        }
        if role == .mac {
            if status == .connected, let latestSnapshot {
                // Re-send the last position so dropping the final drag packet cannot leave
                // the phone permanently at the previous position. Same sequence = no replay.
                transmit(latestSnapshot, mode: .unreliable)
            } else { inviteIfPossible() }
        } else if isReceiving, let lastReceivedAt, now.timeIntervalSince(lastReceivedAt) > 2 {
            isReceiving = false
            onInterrupted?()
        }
    }

    private func inviteIfPossible() {
        guard status == .searching, pendingPeer == nil, Date() >= retryAt,
              let browser, let session,
              let peer = availablePeers.keys.sorted(by: { $0.displayName < $1.displayName }).first
        else { return }
        pendingPeer = peer
        invitationDeadline = Date().addingTimeInterval(8)
        status = .connecting
        peerName = peer.displayName
        browser.invitePeer(peer, to: session, withContext: Self.invitation, timeout: 8)
    }

    private func handle(_ event: PeerEvent) {
        switch event {
        case let .found(source, peer, info):
            guard source === browser, info?["role"] == "phone", info?["version"] == "1" else { return }
            availablePeers[peer] = peer.displayName
            inviteIfPossible()
        case let .lost(source, peer):
            guard source === browser else { return }
            availablePeers.removeValue(forKey: peer)
        case let .invited(source, peer, context, reply):
            guard source === advertiser, context == Self.invitation, let session,
                  session.connectedPeers.isEmpty, pendingPeer == nil else {
                reply(false, nil)
                return
            }
            pendingPeer = peer
            invitationDeadline = Date().addingTimeInterval(8)
            status = .connecting
            peerName = peer.displayName
            reply(true, session)
        case let .state(source, peer, state):
            guard source === session else { return }
            switch state {
            case .connected:
                status = .connected
                peerName = peer.displayName
                pendingPeer = nil
                invitationDeadline = nil
                lastError = nil
                inbox = HarnessPacketInbox()
                if role == .mac, let latestSnapshot { transmit(latestSnapshot, mode: .unreliable) }
            case .connecting:
                status = .connecting
                if invitationDeadline == nil { invitationDeadline = Date().addingTimeInterval(8) }
            case .notConnected:
                guard source.connectedPeers.isEmpty else { return }
                let wasReceiving = isReceiving
                isReceiving = false
                status = .searching
                peerName = nil
                pendingPeer = nil
                invitationDeadline = nil
                retryAt = Date().addingTimeInterval(1)
                inbox = HarnessPacketInbox()
                if wasReceiving { onInterrupted?() }
            @unknown default: break
            }
        case let .data(source, peer, data):
            guard role == .phone, source === session, source.connectedPeers.contains(peer),
                  data.count <= 65_536,
                  let packet = try? JSONDecoder().decode(HarnessPacket.self, from: data),
                  packet.isValid else { return }
            let wasInterrupted = !isReceiving
            let delivery = inbox.accept(packet, recovering: wasInterrupted)
            guard delivery != .invalid else { return }
            lastReceivedAt = Date()
            isReceiving = true
            guard delivery == .guidance else { return }
            receivedCount += 1
            onGuidance?(packet.state)
        case let .failed(source, message):
            guard source === browser || source === advertiser else { return }
            lastError = message
            restartAt = Date().addingTimeInterval(3)
        }
    }

    private static func isValid(_ state: GuidanceState) -> Bool {
        guard state.timestamp.timeIntervalSince1970.isFinite else { return false }
        guard let vector = state.vector else { return true }
        return vector.direction.dx.isFinite && vector.direction.dy.isFinite
            && vector.normalizedDistance.isFinite && vector.normalizedDistance >= 0
    }
}

// Multipeer calls delegates on its own queues. Events carry framework handles only
// to MainActor for identity checks and session operations; the bridge has no mutable state.
private enum PeerEvent: @unchecked Sendable {
    case found(MCNearbyServiceBrowser, MCPeerID, [String: String]?)
    case lost(MCNearbyServiceBrowser, MCPeerID)
    case invited(MCNearbyServiceAdvertiser, MCPeerID, Data?, (Bool, MCSession?) -> Void)
    case state(MCSession, MCPeerID, MCSessionState)
    case data(MCSession, MCPeerID, Data)
    case failed(AnyObject, String)
}

private final class PeerDelegate: NSObject, MCSessionDelegate, MCNearbyServiceBrowserDelegate,
    MCNearbyServiceAdvertiserDelegate, @unchecked Sendable {
    private let receive: @Sendable (PeerEvent) -> Void
    init(receive: @escaping @Sendable (PeerEvent) -> Void) { self.receive = receive }
    func session(_ session: MCSession, peer peerID: MCPeerID, didChange state: MCSessionState) {
        receive(.state(session, peerID, state))
    }
    func session(_ session: MCSession, didReceive data: Data, fromPeer peerID: MCPeerID) {
        receive(.data(session, peerID, data))
    }
    func session(_ session: MCSession, didReceive stream: InputStream, withName streamName: String, fromPeer peerID: MCPeerID) {}
    func session(_ session: MCSession, didStartReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, with progress: Progress) {}
    func session(_ session: MCSession, didFinishReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, at localURL: URL?, withError error: (any Error)?) {}
    func browser(_ browser: MCNearbyServiceBrowser, foundPeer peerID: MCPeerID, withDiscoveryInfo info: [String: String]?) {
        receive(.found(browser, peerID, info))
    }
    func browser(_ browser: MCNearbyServiceBrowser, lostPeer peerID: MCPeerID) { receive(.lost(browser, peerID)) }
    func browser(_ browser: MCNearbyServiceBrowser, didNotStartBrowsingForPeers error: any Error) {
        receive(.failed(browser, error.localizedDescription))
    }
    func advertiser(_ advertiser: MCNearbyServiceAdvertiser, didReceiveInvitationFromPeer peerID: MCPeerID,
                    withContext context: Data?, invitationHandler: @escaping (Bool, MCSession?) -> Void) {
        receive(.invited(advertiser, peerID, context, invitationHandler))
    }
    func advertiser(_ advertiser: MCNearbyServiceAdvertiser, didNotStartAdvertisingPeer error: any Error) {
        receive(.failed(advertiser, error.localizedDescription))
    }
}
