# Mac Harness to iPhone

The Mac generates `GuidanceState` using the existing `HarnessModel` and
`MockGuidance`. `HarnessConnection` implements `FeedbackEngine` by sending these
states to a nearby iPhone. The shared `HarnessConnectivity` package handles
discovery, encrypted sessions, encoding, delivery, and reconnecting.

Both apps start the connection when active and stop it in the background. The
iPhone integration is enabled only in DEBUG builds. On relaunch both sides start
discovery automatically. Keep both apps in the foreground for blindfold tests.
The phone advertises; the Mac invites one matching phone. With several phones
running this developer service, stop the receiver on the phones you do not want
to use. There is no device picker yet.

## Mac UI

The existing `HarnessView` receives its `HarnessModel`. To observe connectivity:

```swift
@Environment(HarnessConnection.self) private var connection
```

Display `connection.peer.status` (`stopped`, `searching`, `connecting`,
`connected`), `peerName`, and `lastError`. A Retry button may call
`connection.reconnect()`; normal restarts do not need a button.

For dot dragging, convert the pointer into normalized panel coordinates and call
`model.moveFingertip(to: PanelPoint(x: x, y: y))`. The origin is top-left and y
increases downward. This method updates both axes together and cancels an
auto-walk. Do not send network messages from the view or assign x and y
separately for one drag update. Existing sliders, target selection, quality
selection, auto-walk, and outcome buttons already feed the remote engine.

Preserve the existing ability to put the fingertip outside 0...1; it is a useful
guidance test. `model.fire(_:)` sends a one-off outcome reliably.

## iPhone UI

Implement `Debug/HarnessReceiverView.swift`, then add a NavigationLink from
`DebugMenu`. The root already owns the receiving controller and supplies it to
the environment:

```swift
@Environment(HarnessConnection.self) private var connection
```

Show connection status, peer name, last error, and whether
`connection.peer.isReceiving` is true. For diagnostics you can display
`connection.lastState`, `connection.lastOutcome`,
`connection.peer.receivedCount`, and `connection.peer.lastReceivedAt`.
`isReceiving` becomes false if no valid packet arrives for two seconds, even if
the network session still reports connected.

Optional controls call `start()`, `stop()`, or `reconnect()` on the controller.
`setFeedbackEnabled(_:)` pauses feedback while leaving reception and inspection
running. Re-enabling resumes the current geometry without repeating an old
outcome. The root handles foreground/background transitions; do not create a
second connection in the page or run the camera pipeline into the same feedback
engine during a Harness session.

## Feedback integration

The current default is `HarnessConsoleFeedback`, which prints received states
and keeps no growing history. `lastState` and `lastOutcome` remain available to
the UI. This does not produce physical haptics or audio.

When the real implementation is ready, construct the root controller with
`HarnessConnection(feedback: LiveFeedbackEngine())` and import ContourFeedback.
Do not make that switch while `LiveFeedbackEngine` still contains `fatalError`.
The injected engine must return promptly from `present(_:)`; the receiver
serializes calls, coalesces pending geometry, and preserves outcome order.
Disconnect or a two-second receive timeout delivers `.lostTracking`; pausing
feedback delivers a state with no vector and no outcome, which the real engine
should interpret as stopping continuous feedback.

## Wire protocol and configuration

Both targets link the same package and declare `_contour-harness._tcp` in
`Config/Harness-Info.plist`, together with the local network usage description.
Allow Local Network access when the OS asks. The service type is
`contour-harness`; discovery and invitation contexts check protocol version 1.

Each JSON packet carries a version, a sender run UUID, a sequence number, a kind,
and a Codable `GuidanceState`. Continuous snapshots use unreliable immediate
delivery, with a repeated snapshot every 250 ms so a dropped final drag update
can recover. Duplicate and older snapshots do not replay feedback. Outcomes use
reliable delivery, are deduplicated separately, and are never replayed after
reconnecting. Sessions require encryption. Invalid versions, nonfinite geometry,
unexpected peers, and oversized packets are rejected.

## On-device acceptance checks

1. Launch Harness on the Mac and a DEBUG ContourApp build on the iPhone. Allow
   local network access and verify automatic connection.
2. Move the sliders/dot; verify received geometry and direction, including y-down
   and off-panel positions. With real feedback integrated, feel/hear the changes
   immediately. The 250 ms resend is recovery, not a delay on ordinary updates.
3. Fire each outcome and verify it plays once.
4. Restart the phone app, then restart Harness, and verify automatic reconnection
   and restoration of current geometry without replaying previous outcomes.
5. Interrupt connectivity or background one app. Verify the phone does not keep
   guiding from stale geometry and resumes when the apps reconnect.

Protocol unit tests cover Codable compatibility, duplicate/out-of-order
snapshots, timeout recovery of an unchanged position, separately ordered outcomes,
and invalid protocol/session/geometry data. Network discovery, physical feedback,
and perceived latency still require a Mac and iPhone test.
